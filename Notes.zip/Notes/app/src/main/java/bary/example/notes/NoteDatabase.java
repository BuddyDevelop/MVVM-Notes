package bary.example.notes;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database( entities = {Note.class}, version = 1, exportSchema = false)
public abstract class NoteDatabase extends RoomDatabase {
    private static NoteDatabase mInstance;
    public abstract NoteDao noteDao();

    public static synchronized NoteDatabase getInstance( Context context ){
        if( mInstance == null ){
            mInstance = Room.databaseBuilder( context.getApplicationContext(),
                    NoteDatabase.class, "note_database")
                    .fallbackToDestructiveMigration()
                    .addCallback( roomCallback )
                    .build();
        }

        return mInstance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate( @NonNull SupportSQLiteDatabase db ) {
            super.onCreate( db );
            new PopulateDbAsyncTask( mInstance ).execute(  );
        }

        @Override
        public void onOpen( @NonNull SupportSQLiteDatabase db ) {
            super.onOpen( db );
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void>{
        private NoteDao mNoteDao;

        private PopulateDbAsyncTask( NoteDatabase db ){
            mNoteDao = db.noteDao();
        }

        @Override
        protected Void doInBackground( Void... voids ) {
            mNoteDao.insert( new Note( "Title", "Description", 5 ) );
            mNoteDao.insert( new Note( "Title 1", "Description 1", 1 ) );
            mNoteDao.insert( new Note( "Title 2", "Description 2", 2 ) );
            mNoteDao.insert( new Note( "Title 3", "Description 3", 4 ) );
            mNoteDao.insert( new Note( "Title 4", "Description 4", 8 ) );
            mNoteDao.insert( new Note( "Title 5", "Description 5", 5 ) );
            mNoteDao.insert( new Note( "Title 6", "Description 6", 6 ) );
            mNoteDao.insert( new Note( "Title 7", "Description 7", 7 ) );
            mNoteDao.insert( new Note( "Title 8", "Description 8", 11 ) );
            mNoteDao.insert( new Note( "Title 9", "Description 9", 2 ) );
            mNoteDao.insert( new Note( "Title 11", "Description 11", 12 ) );
            mNoteDao.insert( new Note( "Title 12", "Description 11", 14 ) );
            mNoteDao.insert( new Note( "Title 13", "Description 11", 15 ) );
            mNoteDao.insert( new Note( "Title 14", "Description 11", 16 ) );



            return null;
        }
    }
}
